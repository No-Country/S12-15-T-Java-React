package com.nocountry.S12G15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S12G15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
