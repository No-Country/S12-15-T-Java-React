package com.nocountry.S12G15.enums;

import lombok.Getter;

@Getter
public enum RolUser {
    ADMIN,
    USER,
}
