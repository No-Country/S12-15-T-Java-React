package com.nocountry.S12G15.dto.response;

public class SpaceResponseDTO {
}
